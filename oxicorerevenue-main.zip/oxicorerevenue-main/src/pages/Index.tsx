import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LoadingScreen } from "@/components/dashboard/LoadingScreen";
import { Header } from "@/components/dashboard/Header";
import { KPICard } from "@/components/dashboard/KPICard";
import { ConversionFunnel } from "@/components/dashboard/ConversionFunnel";
import { FunnelInsights } from "@/components/dashboard/FunnelInsights";
import { CloserCard } from "@/components/dashboard/CloserCard";
import { SDRCard } from "@/components/dashboard/SDRCard";
import { PacingStatus } from "@/components/dashboard/PacingStatus";

// Import actual photos
import brunoPic from "@/assets/bruno.png";
import joaoPic from "@/assets/joao.png";
import danielPic from "@/assets/daniel.png";
import marceloPic from "@/assets/marcelo.png";

const API_KEY = "AIzaSyDTN7IBjVdS6hUOUup34NPKs_Xv8nzMiGY";
const SHEET_ID = "1gvcSqx24Bid5m5aRzImTMM6JQdvGcTPQi7JSp55KwBs";
const SHEET_NAME = "FEV 26";
const MAIN_RANGE = "A1:U95";

// Funnel data from separate sheet (B2:O52)
const FUNNEL_SHEET_ID = "1cGL35xQAqusrt-TlqZ2rvtHtPFTcbMmkJ7oK72wMDoY";
const FUNNEL_SHEET_NAME = "FEV 26";
const FUNNEL_RANGE = "B2:O52";
// SDR data is in main sheet A7:K42

const AVATARS = {
  bruno: brunoPic,
  joao: joaoPic,
  daniel: danielPic,
  marcelo: marceloPic,
};

interface DashboardData {
  meta: number;
  receita: number;
  naRua: number;
  cpv: number;
  vendasC: number;
  // Funnel data from separate sheet
  leads: number;
  contatos: number;
  marcados: number;
  acontecidos: number;
  // Funnel cost metrics
  cpl: number;
  cpc: number;
  cpm: number;
  cpr: number;
  funnelCpv: number;
  funnelInvest: number;
  ticketMedio: number;
  roas: number;
  // Strategic
  invest: number;
  diasT: number;
  diasH: number;
  bruno: number;
  joao: number;
  danielMarcadas: number;
  marceloMarcadas: number;
  progReal: number;
  progIdeal: number;
  gap: number;
}

const parseC = (v: unknown): number => {
  if (!v) return 0;
  return Number(String(v).replace(/[^0-9,.-]+/g, "").replace(/\./g, "").replace(",", ".")) || 0;
};

const formatC = (v: number): string =>
  new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    maximumFractionDigits: 0,
  }).format(v);

const getDirectVal = (data: string[][], rowIdx: number, colIdx: number): string => {
  return data[rowIdx]?.[colIdx] || "0";
};

const findByLabel = (data: string[][], label: string): string => {
  const search = label.toUpperCase();
  for (let r = 0; r < data.length; r++) {
    if (!data[r]) continue;
    for (let c = 0; c < data[r].length; c++) {
      if (data[r][c]?.toString().trim().toUpperCase() === search) {
        const row = data[r];
        for (let i = 1; i <= 6; i++) {
          if (row[c + i]?.toString().trim() !== "") return row[c + i];
        }
      }
    }
  }
  return "0";
};

/**
 * Get SDR totals from SDR section (A7:K42)
 * Structure from screenshot (image-12):
 * - Headers row: DANIEL spans cols B-E, MARCELO spans cols F-I
 * - Sub-headers: Show | No Show | Marcadas | Remarcada for each SDR
 * - Data rows: Dia | day name | Daniel values | Marcelo values
 * - Summary row at bottom of data: shows totals like "0 0 2 0" | "0 0 0 0"  
 * - TOTAL label rows below summary
 * 
 * Looking at image-12, the TOTAL MARCADAS row shows:
 * - Column A: "TOTAL MARCADAS"
 * - Column B: 2 (this is Daniel's total)
 * - Column F: 0 (this is Marcelo's total)
 * 
 * But wait - the range starts at A7, so headers are offset.
 * Let me try multiple column positions to find the correct one.
 */
const getSDRTotals = (data: string[][]) => {
  const res = { 
    danielShow: 0, danielNoShow: 0, danielMarcadas: 0, danielRemarcadas: 0,
    marceloShow: 0, marceloNoShow: 0, marceloMarcadas: 0, marceloRemarcadas: 0 
  };
  
  // Find "TOTAL SHOW" row - the row just before it has individual SDR subtotals
  for (let r = 0; r < Math.min(data.length, 60); r++) {
    const row = data[r];
    if (!row) continue;
    
    const cellA = row[0]?.toString().trim().toUpperCase() || "";
    
    if (cellA === "TOTAL SHOW") {
      // Scan backwards to find the subtotal row with numeric data
      for (let i = 1; i <= 5; i++) {
        const candidateRow = data[r - i];
        if (!candidateRow) continue;
        
        // Check if any SDR column has a value > 0
        const hasData = [2, 3, 4, 5, 7, 8, 9, 10].some(idx => parseC(candidateRow[idx]) > 0);
        if (hasData) {
          console.log("SDR summary row found at offset -" + i + ":", JSON.stringify(candidateRow));
          // Daniel: C-F = indices 2,3,4,5
          res.danielShow = parseC(candidateRow[2]);
          res.danielNoShow = parseC(candidateRow[3]);
          res.danielMarcadas = parseC(candidateRow[4]);
          res.danielRemarcadas = parseC(candidateRow[5]);
          // Marcelo: H-K = indices 7,8,9,10
          res.marceloShow = parseC(candidateRow[7]);
          res.marceloNoShow = parseC(candidateRow[8]);
          res.marceloMarcadas = parseC(candidateRow[9]);
          res.marceloRemarcadas = parseC(candidateRow[10]);
          break;
        }
      }
      break;
    }
  }
  
  console.log("SDR Totals final:", res);
  return res;
};

/**
 * Get METAS table data from M1:S21 range (FEV 2026)
 * Columns: M=Label, N=Meta, O=JOÃO, P=BRUNO, Q=LUIS F., R=Total
 */
const getMetasTable = (data: string[][]) => {
  const res = {
    reuniaoMarcadas: { meta: 0, joao: 0, bruno: 0, luis: 0, total: 0 },
    reunioesRealizadas: { meta: 0, joao: 0, bruno: 0, luis: 0, total: 0 },
    convPct: { meta: "", joao: "", bruno: "", luis: "", total: "" },
    vendas: { meta: 0, joao: 0, bruno: 0, luis: 0, total: 0 },
    ticket: { meta: 0, joao: 0, bruno: 0, luis: 0, total: 0 },
    receita: { meta: 0, joao: 0, bruno: 0, luis: 0, total: 0 },
    txShow: { meta: "", joao: "", bruno: "", luis: "", total: "" },
    naRua: 0,
  };

  // Find the METAS header row (column M = index 12)
  for (let r = 0; r < data.length; r++) {
    const row = data[r];
    if (!row) continue;
    
    // Look for "METAS" label in column M (index 12)
    if (row[12]?.toString().trim().toUpperCase() === "METAS") {
      // Row+1 = Reunião Marcadas
      const marcadasRow = data[r + 1];
      if (marcadasRow) {
        res.reuniaoMarcadas.meta = parseC(marcadasRow[13]);
        res.reuniaoMarcadas.joao = parseC(marcadasRow[14]);
        res.reuniaoMarcadas.bruno = parseC(marcadasRow[15]);
        res.reuniaoMarcadas.luis = parseC(marcadasRow[16]);
        res.reuniaoMarcadas.total = parseC(marcadasRow[17]);
      }
      
      // Row+2 = Reuniões realizadas
      const realizadasRow = data[r + 2];
      if (realizadasRow) {
        res.reunioesRealizadas.meta = parseC(realizadasRow[13]);
        res.reunioesRealizadas.joao = parseC(realizadasRow[14]);
        res.reunioesRealizadas.bruno = parseC(realizadasRow[15]);
        res.reunioesRealizadas.luis = parseC(realizadasRow[16]);
        res.reunioesRealizadas.total = parseC(realizadasRow[17]);
      }
      
      // Row+3 = Conv %
      const convRow = data[r + 3];
      if (convRow) {
        res.convPct.meta = convRow[13]?.toString() || "";
        res.convPct.joao = convRow[14]?.toString() || "";
        res.convPct.bruno = convRow[15]?.toString() || "";
        res.convPct.luis = convRow[16]?.toString() || "";
        res.convPct.total = convRow[17]?.toString() || "";
      }
      
      // Row+4 = Vendas
      const vendasRow = data[r + 4];
      if (vendasRow) {
        res.vendas.meta = parseC(vendasRow[13]);
        res.vendas.joao = parseC(vendasRow[14]);
        res.vendas.bruno = parseC(vendasRow[15]);
        res.vendas.luis = parseC(vendasRow[16]);
        res.vendas.total = parseC(vendasRow[17]);
      }
      
      // Row+5 = Ticket
      const ticketRow = data[r + 5];
      if (ticketRow) {
        res.ticket.meta = parseC(ticketRow[13]);
        res.ticket.joao = parseC(ticketRow[14]);
        res.ticket.bruno = parseC(ticketRow[15]);
        res.ticket.luis = parseC(ticketRow[16]);
        res.ticket.total = parseC(ticketRow[17]);
      }
      
      // Row+6 = Receita
      const receitaRow = data[r + 6];
      if (receitaRow) {
        res.receita.meta = parseC(receitaRow[13]);
        res.receita.joao = parseC(receitaRow[14]);
        res.receita.bruno = parseC(receitaRow[15]);
        res.receita.luis = parseC(receitaRow[16]);
        res.receita.total = parseC(receitaRow[17]);
      }
      
      // Row+7 = TX SHOW
      const txShowRow = data[r + 7];
      if (txShowRow) {
        res.txShow.meta = txShowRow[13]?.toString() || "";
        res.txShow.joao = txShowRow[14]?.toString() || "";
        res.txShow.bruno = txShowRow[15]?.toString() || "";
        res.txShow.luis = txShowRow[16]?.toString() || "";
        res.txShow.total = txShowRow[17]?.toString() || "";
      }
      
      // Row+12 = Na Rua (offset from METAS header)
      const naRuaRow = data[r + 12];
      if (naRuaRow) {
        res.naRua = parseC(naRuaRow[13]);
      }
      
      break;
    }
  }
  
  return res;
};

const processPerformance = (data: string[][]) => {
  let leadsRow = -1,
    monthCol = -1;
  const res = { janLeads: 0 };

  for (let r = 0; r < data.length; r++) {
    if (data[r]?.some((c) => c?.toString().toUpperCase() === "LEADS")) {
      leadsRow = r;
      monthCol = data[r].findIndex((c) => c?.toString().toUpperCase() === "DATA LEAD");
      break;
    }
  }

  if (leadsRow > -1) {
    for (let r = leadsRow + 1; r < data.length; r++) {
      const row = data[r];
      if (!row) continue;
      const dateVal = row[monthCol]?.toString().trim().toUpperCase() || "";
      if (dateVal.includes("JANEIRO")) {
        res.janLeads++;
      }
    }
  }
  return res;
};

/**
 * Fetch funnel data from separate sheet (B2:O52 in FEV 26)
 * Structure: Contains funnel metrics like Total de Leads, Contatos, Marcados, Acontecidos, Vendas
 * Also contains: Orçamento, Ticket Médio, CPL, etc.
 */
const fetchFunnelData = async () => {
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${FUNNEL_SHEET_ID}/values/'${FUNNEL_SHEET_NAME}'!${FUNNEL_RANGE}?valueRenderOption=FORMATTED_VALUE&key=${API_KEY}`
  );
  const json = await response.json();
  if (json.error) throw new Error(json.error.message);
  
  const rows: string[][] = json.values || [];
  const res = { 
    leads: 0, contatos: 0, marcados: 0, acontecidos: 0, vendas: 0,
    invest: 0, receita: 0,
    // Calculated metrics
    cpl: 0, cpc: 0, cpm: 0, cpr: 0, cpv: 0, ticketMedio: 0, roas: 0,
  };
  
  // C7 in range B2:O52 means:
  // Row 7 - Row 2 = index 5
  // Column C - Column B = index 1
  // So C7 = rows[5][1]
  res.invest = Math.abs(parseC(rows[5]?.[1]));
  console.log("Invest from C7:", res.invest, "Raw value:", rows[5]?.[1]);
  
  // C17 in range B2:O52 means:
  // Row 17 - Row 2 = index 15
  // Column C - Column B = index 1
  // So C17 = rows[15][1]
  res.leads = parseC(rows[15]?.[1]);
  console.log("Leads from C17:", res.leads, "Raw value:", rows[15]?.[1]);
  
  console.log("Funnel raw data:", res);
  
  return res;
};

const SYNC_INTERVAL = 20;

const Index = () => {
  const [loading, setLoading] = useState(true);
  const [syncTime, setSyncTime] = useState("Syncing...");
  const [status, setStatus] = useState("Connecting");
  const [data, setData] = useState<DashboardData | null>(null);
  const [countdown, setCountdown] = useState(SYNC_INTERVAL);
  const syncArena = useCallback(async () => {
    try {
      // Fetch main sheet and funnel data in parallel
      const [mainResponse, funnelData] = await Promise.all([
        fetch(
          `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/'${SHEET_NAME}'!${MAIN_RANGE}?valueRenderOption=FORMATTED_VALUE&key=${API_KEY}`
        ),
        fetchFunnelData()
      ]);
      
      const json = await mainResponse.json();

      if (json.error) throw new Error(json.error.message);

      const sheetData: string[][] = json.values || [];
      const sdr = getSDRTotals(sheetData);
      const metas = getMetasTable(sheetData);

      const meta = parseC(findByLabel(sheetData, "META DO MÊS"));
      const diasT = parseInt(findByLabel(sheetData, "Dias úteis mês")) || 1;
      const diasH = parseInt(findByLabel(sheetData, "Dias úteis hoje")) || 0;
      const idealVal = (meta / diasT) * diasH;

      // CPV from METAS table
      const cpvValue = parseC(findByLabel(sheetData, "CPV"));

      // Use METAS table data for closers
      const receitaTotal = metas.receita.total;
      const vendasTotal = metas.vendas.total;
      
      // Get LEADS from funnel sheet C17
      const leads = funnelData.leads || 0;
      console.log("Using leads:", leads);
      const marcados = metas.reuniaoMarcadas.total || funnelData.marcados || 0;
      const contatos = marcados; // Taxa de Contato = Reuniões Marcadas
      const acontecidos = metas.reunioesRealizadas.total || funnelData.acontecidos || 0;
      const vendas = vendasTotal || funnelData.vendas || 0;
      const invest = Math.abs(funnelData.invest || 0); // Ensure positive value
      const receita = receitaTotal || funnelData.receita || 0;
      
      // Calculate metrics using formulas
      const cpl = leads > 0 ? invest / leads : 0;
      const cpc = contatos > 0 ? invest / contatos : 0;
      const cpm = marcados > 0 ? invest / marcados : 0;
      const cpr = acontecidos > 0 ? invest / acontecidos : 0;
      const funnelCpv = vendas > 0 ? invest / vendas : 0;
      const ticketMedio = vendas > 0 ? receita / vendas : 0;
      const roas = invest > 0 ? receita / invest : 0;
      
      console.log("Funnel calculations:", { leads, contatos, marcados, acontecidos, vendas, invest, receita, cpl, cpc, cpm, cpr, funnelCpv, ticketMedio, roas });

      const dashData: DashboardData = {
        meta,
        naRua: metas.naRua || parseC(findByLabel(sheetData, "Na Rua")),
        diasT,
        diasH,
        // Funnel data
        leads,
        contatos,
        marcados,
        acontecidos,
        // Funnel cost metrics (calculated)
        cpl,
        cpc,
        cpm,
        cpr,
        funnelCpv,
        funnelInvest: invest,
        ticketMedio,
        roas,
        vendasC: vendasTotal,
        receita: receitaTotal,
        invest: parseC(getDirectVal(sheetData, 375, 20)),
        cpv: cpvValue,
        // From METAS table - individual closer receita
        bruno: metas.receita.bruno,
        joao: metas.receita.joao,
        danielMarcadas: sdr.danielMarcadas,
        marceloMarcadas: sdr.marceloMarcadas,
        progReal: meta > 0 ? (receitaTotal / meta) * 100 : 0,
        progIdeal: meta > 0 ? (idealVal / meta) * 100 : 0,
        gap: receitaTotal - idealVal,
      };

      setData(dashData);
      setStatus("Live Dark Active");
      setSyncTime(`Última Sync: ${new Date().toLocaleTimeString()}`);
      setLoading(false);
    } catch (err) {
      console.error(err);
      setStatus("Sync Failure");
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    syncArena();
    setCountdown(SYNC_INTERVAL);
    
    const syncInterval = setInterval(() => {
      syncArena();
      setCountdown(SYNC_INTERVAL);
    }, SYNC_INTERVAL * 1000);
    
    const countdownInterval = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : SYNC_INTERVAL));
    }, 1000);
    
    return () => {
      clearInterval(syncInterval);
      clearInterval(countdownInterval);
    };
  }, [syncArena]);


  return (
    <>
      <AnimatePresence>{loading && <LoadingScreen />}</AnimatePresence>

      <div className="p-4 md:p-10 lg:p-14 min-h-screen">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="max-w-[1850px] mx-auto space-y-12"
        >
          <Header syncTime={syncTime} status={status} countdown={countdown} />

          {/* Global Summary */}
          <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <KPICard label="Meta do Mês" value={formatC(data?.meta || 0)} />
            <KPICard
              label="Faturamento Confirmado"
              value={formatC(data?.receita || 0)}
              subtitle={`${data?.vendasC || 0} NEGÓCIOS FECHADOS EM FEV`}
              variant="primary"
            />
            <KPICard label='Negócios "Na Rua"' value={formatC(data?.naRua || 0)} />
            <KPICard
              label="CPV Consolidado"
              value={formatC(data?.cpv || 0)}
              subtitle="Custo Por Venda"
              variant="highlight"
            />
          </section>

          {/* Operational Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Conversion Funnel */}
            <div className="lg:col-span-8 space-y-10">
              <ConversionFunnel
                data={{
                  leads: data?.leads || 0,
                  contatos: data?.contatos || 0,
                  marcados: data?.marcados || 0,
                  acontecidos: data?.acontecidos || 0,
                  vendas: data?.vendasC || 0,
                }}
              />

              <FunnelInsights
                cpl={data?.cpl || 0}
                cpc={data?.cpc || 0}
                cpm={data?.cpm || 0}
                cpr={data?.cpr || 0}
                cpv={data?.funnelCpv || 0}
                invest={data?.funnelInvest || 0}
                ticketMedio={data?.ticketMedio || 0}
                roas={data?.roas || 0}
                formatCurrency={formatC}
              />
            </div>

            {/* Gamification Sidebar */}
            <aside className="lg:col-span-4 space-y-10">
              {/* Top Closers - sorted by revenue */}
              <div className="space-y-6">
                <h3 className="text-xs font-black uppercase tracking-[0.4em] text-muted-foreground px-2 border-l-4 border-primary pl-4 italic">
                  Arena dos Closers
                </h3>
                <div className="space-y-6">
                  {(() => {
                    const closers = [
                      { name: "Bruno", value: data?.bruno || 0, avatar: AVATARS.bruno },
                      { name: "João", value: data?.joao || 0, avatar: AVATARS.joao },
                    ].sort((a, b) => b.value - a.value);
                    
                    // Check if anyone has sales (receita > 0)
                    const hasAnySales = closers.some(c => c.value > 0);
                    
                    return closers.map((closer, idx) => (
                      <CloserCard
                        key={closer.name}
                        name={closer.name}
                        value={formatC(closer.value)}
                        progress={(closer.value / ((data?.meta || 1) / 2)) * 100}
                        avatar={closer.avatar}
                        rank={hasAnySales ? (idx === 0 ? "gold" : "silver") : undefined}
                      />
                    ));
                  })()}
                </div>
              </div>

              {/* SDR Engine - sorted by marcadas */}
              <div className="space-y-6">
                <h3 className="text-xs font-black uppercase tracking-[0.4em] text-muted-foreground px-2 border-l-4 border-emerald pl-4 italic">
                  Motor SDR Fev
                </h3>
                {(() => {
                  const danielVal = data?.danielMarcadas || 0;
                  const marceloVal = data?.marceloMarcadas || 0;
                  const sdrs = [
                    { name: "Daniel", value: danielVal, avatar: AVATARS.daniel },
                    { name: "Marcelo", value: marceloVal, avatar: AVATARS.marcelo },
                  ].sort((a, b) => b.value - a.value);
                  
                  // Check if anyone has marcadas > 0
                  const hasAnyMarcadas = sdrs.some(s => s.value > 0);
                  
                  return sdrs.map((sdr, idx) => (
                    <SDRCard
                      key={sdr.name}
                      name={sdr.name}
                      value={sdr.value}
                      progress={(sdr.value / 70) * 100}
                      avatar={sdr.avatar}
                      rank={hasAnyMarcadas ? (idx === 0 ? "gold" : "silver") : undefined}
                    />
                  ));
                })()}
              </div>

              {/* Pacing Status */}
              <PacingStatus
                realPct={data?.progReal || 0}
                idealPct={data?.progIdeal || 0}
                gap={data?.gap || 0}
                formatCurrency={formatC}
              />
            </aside>
          </div>

          {/* Footer */}
          <footer className="pt-10 pb-16 text-center border-t border-foreground/5 opacity-40">
            <p className="text-[10px] font-black text-muted-foreground uppercase tracking-[0.5em]">
              V4 COMPANY • PERFORMANCE ARENA • DANIEL CANQUERINO
            </p>
          </footer>
        </motion.div>
      </div>
    </>
  );
};

export default Index;
